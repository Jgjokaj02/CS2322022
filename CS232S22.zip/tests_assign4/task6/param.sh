#!/bin/bash
expected="construct_3_strs.c"

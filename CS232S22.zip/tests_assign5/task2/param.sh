#!/bin/bash
expected="wordstats2.c"

#!/bin/bash
cmd="gcc -Wall -std=c11 wordstats2.c -o wordstats2"
executable="wordstats2"

#!/bin/bash
expected="array.c array_test.c"

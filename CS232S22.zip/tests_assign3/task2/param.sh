#!/bin/bash
expected="convert_2.c"

#!/bin/bash
expected="flip_bits.c test_flip_bits.c"
